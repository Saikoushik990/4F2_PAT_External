public class Basics_java {
    //Widening
    /*public static void main(String[] args){
        int a=10;
        float f=a;
        System.out.println(a);
        System.out.println(f);
    }}*/
//Narrowing
    /*public static void main(String[] args){
        float f=10.5f;
//int a=f;//Compile time error
        int a=(int)f;
        System.out.println(f);
        System.out.println(a);
    }}  */

    /*class Simple{
        public static void main(String[] args){
//Overflow
            int a=130;
            byte b=(byte)a;
            System.out.println(a);
            System.out.println(b);
        }}  */
//unary operator
    public static void main(String args[]){
        int a=10;
        int b=-10;
        boolean c=true;
        boolean d=false;
        System.out.println(~a);
        System.out.println(~b);
        System.out.println(!c);
        System.out.println(!d);
    }}



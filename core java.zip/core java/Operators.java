class Operators {
    /*public static void main(String args[]){
        int a=10;
        int b=5;
        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(a/b);
        System.out.println(a%b);
    }}*/

    /*public static void main(String args[]){
        System.out.println(10<<2);
        System.out.println(10<<3);
    }}*/

/*public static void main(String args[]){
    System.out.println(20>>2);
    System.out.println(20>>>2);
    System.out.println(-20>>2);
    System.out.println(-20>>>2);
}}  */

    /*public static void main(String args[]){
        int a=10;
        int b=5;
        int c=20;
        System.out.println(a<b&&a<c);//false && true = false
        System.out.println(a<b&a<c);//false & true = false
    }}  */

   /* public static void main(String args[]){
        int a=10;
        int b=5;
        int c=20;
        System.out.println(a>b||a<c);
        System.out.println(a>b|a<c);

        System.out.println(a>b||a++<c);
        System.out.println(a);
        System.out.println(a>b|a++<c);
        System.out.println(a);
    }}  */
//tenaryoperator

/*public static void main(String args[]){
int a=10;
int b=5;
int min=(a<b)?a:b;
System.out.println(min);
}}  */}

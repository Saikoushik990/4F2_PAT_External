import java.util.Scanner;
public class Java_Practice {
    public static void main(String[] args){
        /*Panlindrome*/
        /*Scanner sc = new Scanner(System.in);
        String str = sc.next();

        StringBuilder sb = new StringBuilder(str);
        sb.reverse();
        String rev = sb.toString();

        if(str.equals(rev)){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }

*/
        ///functions(methods)///
       /* square(5);
    }
    static void square(int num){
        System.out.print(num*num);
    }
    */
}}
